package com.mycompany.natasha_moremi_prog6112_assig_2;

import javax.swing.*;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class NATASHA_MOREMI_PROG6112_ASSIG_2 {

    public static void main(String[] args) {
        ControlCentre.boot();
    }

    // Contract every rescue type must honour.
    interface Workflow {
        String PENDING  = "New Rescue";
        String RUNNING  = "Rescue in Progress";
        String MONITOR  = "Under Observation";
        String CLOSED   = "Rescue Completed";

        void launch();
        void conclude();
        String briefing();
    }

    // Abstract base: holds shared fields, declares type-specific behaviour.
    static abstract class Incident implements Workflow {

        private String refNo, creature, breed, zone, warden, phase;
        private int duration;
        private double rate;

        Incident(String refNo, String creature, String breed, String zone,
                 String warden, int duration, double rate, String phase) {
            this.refNo = refNo;
            this.creature = creature;
            this.breed = breed;
            this.zone = zone;
            this.warden = warden;
            this.duration = duration;
            this.rate = rate;
            this.phase = phase;
        }

        String refNo()    { return refNo; }
        String creature() { return creature; }
        String breed()    { return breed; }
        String zone()     { return zone; }
        String warden()   { return warden; }
        String phase()    { return phase; }
        int duration()    { return duration; }
        double rate()     { return rate; }
        void phase(String p) { phase = p; }

        // Base cost: days multiplied by daily rate.
        double baseline() { return duration * rate; }

        // Rands with space as thousands separator and two decimals.
        static String rands(double v) {
            DecimalFormat f = new DecimalFormat("#,##0.00");
            return "R" + f.format(v).replace(",", " ");
        }

        abstract double aggregate();
        abstract String band();
        abstract String classification();
        abstract String extras();
    }

    // Injured rescue: base + vet cost + R5 000 surgery surcharge.
    // Priority: Critical if surgery AND vet >= 12000; High if either; Medium if vet >= 4000; else Low.
    static class Trauma extends Incident {

        private String description;
        private double medical;
        private boolean operation;

        Trauma(String refNo, String creature, String breed, String zone, String warden,
               int duration, double rate, String phase,
               String description, double medical, boolean operation) {
            super(refNo, creature, breed, zone, warden, duration, rate, phase);
            this.description = description;
            this.medical = medical;
            this.operation = operation;
        }

        String description()  { return description; }
        double medical()      { return medical; }
        boolean operation()   { return operation; }

        @Override double aggregate() {
            return baseline() + medical + (operation ? 5000.0 : 0.0);
        }

        @Override String band() {
            if (operation && medical >= 12000) return "Critical";
            if (operation || medical >= 12000) return "High";
            if (medical >= 4000)               return "Medium";
            return "Low";
        }

        @Override String classification() { return "Injured Animal Rescue"; }

        @Override String extras() {
            return "Injury Note           : " + description + "\n" +
                   "Medical Cost          : " + rands(medical) + "\n" +
                   "Operation             : " + (operation ? "Yes" : "No");
        }

        @Override public void launch()   { phase(RUNNING); }
        @Override public void conclude() { phase(CLOSED); }

        @Override public String briefing() {
            return "Case ID           : " + refNo() + "\n" +
                   "Type              : " + classification() + "\n" +
                   "Species           : " + breed() + "\n" +
                   "Ranger            : " + warden() + "\n" +
                   "Priority          : " + band() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(aggregate());
        }
    }

    // Orphaned rescue: base + feeding cost + R2 500 foster surcharge.
    // Priority: Critical if age <= 2 AND foster; High if either; Medium if age <= 9; else Low.
    static class Offspring extends Incident {

        private int months;
        private double feedCost;
        private boolean custody;

        Offspring(String refNo, String creature, String breed, String zone, String warden,
                  int duration, double rate, String phase,
                  int months, double feedCost, boolean custody) {
            super(refNo, creature, breed, zone, warden, duration, rate, phase);
            this.months = months;
            this.feedCost = feedCost;
            this.custody = custody;
        }

        int months()        { return months; }
        double feedCost()   { return feedCost; }
        boolean custody()   { return custody; }

        @Override double aggregate() {
            return baseline() + feedCost + (custody ? 2500.0 : 0.0);
        }

        @Override String band() {
            if (months <= 2 && custody) return "Critical";
            if (months <= 2 || custody) return "High";
            if (months <= 9)            return "Medium";
            return "Low";
        }

        @Override String classification() { return "Orphaned Animal Rescue"; }

        @Override String extras() {
            return "Age (months)          : " + months + "\n" +
                   "Feeding Cost          : " + rands(feedCost) + "\n" +
                   "Custody Required      : " + (custody ? "Yes" : "No");
        }

        @Override public void launch()   { phase(RUNNING); }
        @Override public void conclude() { phase(CLOSED); }

        @Override public String briefing() {
            return "Case ID           : " + refNo() + "\n" +
                   "Type              : " + classification() + "\n" +
                   "Species           : " + breed() + "\n" +
                   "Ranger            : " + warden() + "\n" +
                   "Priority          : " + band() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(aggregate());
        }
    }

    // Endangered rescue: base + security cost + R8 000 specialist surcharge.
    // Priority: Critical if specialists AND critically endangered; High if either; Medium if endangered; else Low.
    static class Rare extends Incident {

        private String redList;
        private double guardCost;
        private boolean specialists;

        Rare(String refNo, String creature, String breed, String zone, String warden,
             int duration, double rate, String phase,
             String redList, double guardCost, boolean specialists) {
            super(refNo, creature, breed, zone, warden, duration, rate, phase);
            this.redList = redList;
            this.guardCost = guardCost;
            this.specialists = specialists;
        }

        String redList()      { return redList; }
        double guardCost()    { return guardCost; }
        boolean specialists() { return specialists; }

        @Override double aggregate() {
            return baseline() + guardCost + (specialists ? 8000.0 : 0.0);
        }

        @Override String band() {
            boolean hot = "Critically Endangered".equalsIgnoreCase(redList);
            if (specialists && hot) return "Critical";
            if (specialists || hot) return "High";
            if ("Endangered".equalsIgnoreCase(redList)) return "Medium";
            return "Low";
        }

        @Override String classification() { return "Endangered Species Rescue"; }

        @Override String extras() {
            return "Red List              : " + redList + "\n" +
                   "Guard Cost            : " + rands(guardCost) + "\n" +
                   "Specialists           : " + (specialists ? "Yes" : "No");
        }

        @Override public void launch()   { phase(RUNNING); }
        @Override public void conclude() { phase(CLOSED); }

        @Override public String briefing() {
            return "Case ID           : " + refNo() + "\n" +
                   "Type              : " + classification() + "\n" +
                   "Species           : " + breed() + "\n" +
                   "Ranger            : " + warden() + "\n" +
                   "Priority          : " + band() + "\n" +
                   "Status            : " + phase() + "\n" +
                   "Total Cost        : " + rands(aggregate());
        }
    }

    // Business layer: stores cases in an ArrayList and enforces unique IDs.
    static class Repository {

        private final ArrayList<Incident> records = new ArrayList<>();

        void save(Incident inc) {
            if (inc == null) throw new IllegalArgumentException("Case cannot be null.");
            String id = inc.refNo();
            if (id == null || id.trim().isEmpty())
                throw new IllegalArgumentException("Case ID cannot be blank.");
            if (fetch(id) != null)
                throw new IllegalArgumentException("Case ID already exists: " + id);
            records.add(inc);
        }

        Incident fetch(String id) {
            if (id == null) return null;
            for (Incident inc : records)
                if (inc.refNo().equalsIgnoreCase(id.trim())) return inc;
            return null;
        }

        boolean reassign(String id, String phase) {
            Incident inc = fetch(id);
            if (inc == null) return false;
            inc.phase(phase);
            return true;
        }

        ArrayList<Incident> all() { return records; }
        int count() { return records.size(); }

        double cumulative() {
            double sum = 0;
            for (Incident inc : records) sum += inc.aggregate();
            return sum;
        }

        boolean registered(String id) { return fetch(id) != null; }
    }

    // JOptionPane user interface; delegates all business logic to Repository.
    static class ControlCentre {

        private static final Repository repo = new Repository();

        static void boot() {
            boolean active = true;
            while (active) {
                String screen =
                        "=====================================\n" +
                        "WILDLIFE RESCUE OPERATIONS SYSTEM\n" +
                        "=====================================\n" +
                        "1. Create Rescue Case\n" +
                        "2. Search Rescue Case\n" +
                        "3. Update Rescue Status\n" +
                        "4. Display All Rescue Cases\n" +
                        "5. Rescue Report\n" +
                        "6. Exit\n" +
                        "=====================================\n" +
                        "Select an option:";

                String option = JOptionPane.showInputDialog(null, screen, "WildLife SA", JOptionPane.PLAIN_MESSAGE);
                if (option == null) { active = false; continue; }

                switch (option.trim()) {
                    case "1": buildIncident();  break;
                    case "2": locateIncident(); break;
                    case "3": revisePhase();    break;
                    case "4": showAll();        break;
                    case "5": generateReport(); break;
                    case "6": active = false; tell("Goodbye."); break;
                    default:  tell("Invalid. Choose 1 to 6.");
                }
            }
        }

        private static void buildIncident() {
            String[] buckets = {
                "Injured Animal Rescue",
                "Orphaned Animal Rescue",
                "Endangered Species Rescue"
            };
            String pick = (String) JOptionPane.showInputDialog(
                    null, "Select rescue type:", "WildLife SA",
                    JOptionPane.QUESTION_MESSAGE, null, buckets, buckets[0]);
            if (pick == null) return;

            String ref = obtain("Enter Rescue Case ID:");
            if (ref == null) return;
            if (repo.registered(ref)) { tell("ID already exists."); return; }

            String creature = obtain("Enter Animal Name:");     if (creature == null) return;
            String breed    = obtain("Enter Species:");         if (breed == null) return;
            String zone     = obtain("Enter Rescue Location:"); if (zone == null) return;
            String warden   = obtain("Enter Assigned Ranger:"); if (warden == null) return;
            Integer duration = obtainInt("Enter Number of Rescue Days:"); if (duration == null) return;
            Double rate      = obtainDbl("Enter Daily Care Cost (R):");   if (rate == null) return;

            try {
                Incident inc;
                if (pick.equals(buckets[0])) {
                    String note = obtain("Enter Injury Description:");            if (note == null) return;
                    Double med  = obtainNonNeg("Veterinary Treatment Cost (R):"); if (med == null) return;
                    boolean op  = confirm("Is Surgery Required?");
                    inc = new Trauma(ref, creature, breed, zone, warden, duration, rate, Workflow.PENDING, note, med, op);
                } else if (pick.equals(buckets[1])) {
                    Integer age = obtainInt("Enter Estimated Age (Months):"); if (age == null) return;
                    Double feed = obtainNonNeg("Feeding Cost (R):");          if (feed == null) return;
                    boolean custody = confirm("Is Foster Care Required?");
                    inc = new Offspring(ref, creature, breed, zone, warden, duration, rate, Workflow.PENDING, age, feed, custody);
                } else {
                    String list = obtain("Enter Conservation Classification:"); if (list == null) return;
                    Double guard = obtainNonNeg("Security Cost (R):");          if (guard == null) return;
                    boolean squad = confirm("Is a Specialist Team Required?");
                    inc = new Rare(ref, creature, breed, zone, warden, duration, rate, Workflow.PENDING, list, guard, squad);
                }
                repo.save(inc);
                tell("Case created.\n\n" + inc.briefing());
            } catch (IllegalArgumentException ex) {
                tell(ex.getMessage());
            }
        }

        private static void locateIncident() {
            String ref = obtain("Enter Rescue Case ID to search:");
            if (ref == null) return;
            Incident inc = repo.fetch(ref);
            if (inc == null) { tell("Not found: " + ref); return; }
            display("Rescue Case Details", elaborate(inc));
        }

        private static void revisePhase() {
            String ref = obtain("Enter Rescue Case ID to update:");
            if (ref == null) return;
            Incident inc = repo.fetch(ref);
            if (inc == null) { tell("Not found: " + ref); return; }

            String[] options = { Workflow.RUNNING, Workflow.MONITOR, Workflow.CLOSED, Workflow.PENDING };
            String next = (String) JOptionPane.showInputDialog(
                    null, "Choose new status for " + inc.refNo() + ":",
                    "Update Status", JOptionPane.QUESTION_MESSAGE,
                    null, options, inc.phase());
            if (next == null) return;

            repo.reassign(ref, next);
            tell("Status updated.\n\n" + inc.briefing());
        }

        private static void showAll() {
            ArrayList<Incident> list = repo.all();
            if (list.isEmpty()) { tell("No rescue cases yet."); return; }

            StringBuilder sb = new StringBuilder();
            sb.append("ALL RESCUE CASES (").append(list.size()).append(")\n");
            sb.append("=====================================\n");
            for (Incident inc : list) {
                sb.append(elaborate(inc)).append("\n-------------------------------------\n");
            }
            display("All Rescue Cases", sb.toString());
        }

        private static void generateReport() {
            ArrayList<Incident> list = repo.all();
            StringBuilder sb = new StringBuilder();
            sb.append("=====================================\n");
            sb.append("WILDLIFE RESCUE REPORT\n");
            sb.append("=====================================\n");

            if (list.isEmpty()) {
                sb.append("No rescue cases to report.\n");
            } else {
                for (Incident inc : list) {
                    sb.append("Case ID          : ").append(inc.refNo()).append("\n");
                    sb.append("Type             : ").append(inc.classification()).append("\n");
                    sb.append("Species          : ").append(inc.breed()).append("\n");
                    sb.append("Location         : ").append(inc.zone()).append("\n");
                    sb.append("Ranger           : ").append(inc.warden()).append("\n");
                    sb.append("Priority         : ").append(inc.band()).append("\n");
                    sb.append("Status           : ").append(inc.phase()).append("\n");
                    sb.append("Total Cost       : ").append(Incident.rands(inc.aggregate())).append("\n");
                    sb.append("-------------------------------------\n");
                }
            }
            sb.append("=====================================\n");
            sb.append("Total Cases      : ").append(repo.count()).append("\n");
            sb.append("Total Cost       : ").append(Incident.rands(repo.cumulative())).append("\n");
            sb.append("=====================================\n");
            display("Wildlife Rescue Report", sb.toString());
        }

        private static String elaborate(Incident inc) {
            return "Case ID           : " + inc.refNo() + "\n" +
                   "Animal Name       : " + inc.creature() + "\n" +
                   "Type              : " + inc.classification() + "\n" +
                   "Species           : " + inc.breed() + "\n" +
                   "Location          : " + inc.zone() + "\n" +
                   "Ranger            : " + inc.warden() + "\n" +
                   "Days              : " + inc.duration() + "\n" +
                   "Daily Cost        : " + Incident.rands(inc.rate()) + "\n" +
                   "Status            : " + inc.phase() + "\n" +
                   "Priority          : " + inc.band() + "\n" +
                   inc.extras() + "\n" +
                   "Total Cost        : " + Incident.rands(inc.aggregate()) + "\n";
        }

        private static void display(String title, String body) {
            JTextArea area = new JTextArea(body);
            area.setEditable(false);
            area.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 12));
            JScrollPane scroll = new JScrollPane(area);
            scroll.setPreferredSize(new Dimension(560, 440));
            JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
        }

        // --- input helpers with validation ---

        private static String obtain(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                if (!s.trim().isEmpty()) return s.trim();
                tell("Cannot be blank.");
            }
        }

        private static Integer obtainInt(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    int v = Integer.parseInt(s.trim());
                    if (v > 0) return v;
                    tell("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    tell("Enter a whole number.");
                }
            }
        }

        private static Double obtainDbl(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v > 0) return v;
                    tell("Must be greater than zero.");
                } catch (NumberFormatException e) {
                    tell("Enter a number.");
                }
            }
        }

        private static Double obtainNonNeg(String prompt) {
            while (true) {
                String s = JOptionPane.showInputDialog(null, prompt, "WildLife SA", JOptionPane.QUESTION_MESSAGE);
                if (s == null) return null;
                try {
                    double v = Double.parseDouble(s.trim());
                    if (v >= 0) return v;
                    tell("Cannot be negative.");
                } catch (NumberFormatException e) {
                    tell("Enter a number.");
                }
            }
        }

        private static boolean confirm(String prompt) {
            return JOptionPane.showConfirmDialog(null, prompt, "WildLife SA",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
        }

        private static void tell(String msg) {
            JOptionPane.showMessageDialog(null, msg, "WildLife SA", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}