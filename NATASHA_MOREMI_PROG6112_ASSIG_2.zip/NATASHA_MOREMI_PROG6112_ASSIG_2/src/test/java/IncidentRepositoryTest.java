package com.mycompany.natasha_moremi_prog6112_assig_2;

import com.mycompany.natasha_moremi_prog6112_assig_2.NATASHA_MOREMI_PROG6112_ASSIG_2.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IncidentRepositoryTest {

    private Repository repo;

    @BeforeEach
    public void setUp() {
        repo = new Repository();
    }

    // ---- cost: base + extras, with and without surcharges ----

    @Test public void traumaNoOperation() {
        Trauma t = new Trauma("R01", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Workflow.PENDING, "Snare", 8500, false);
        assertEquals(18500, t.aggregate(), 0.001);
    }

    @Test public void traumaWithOperation() {
        Trauma t = new Trauma("R02", "Tusker", "African Elephant", "Kruger", "A",
                5, 2000, Workflow.PENDING, "Snare", 8500, true);
        assertEquals(23500, t.aggregate(), 0.001);
    }

    @Test public void offspringNoCustody() {
        Offspring o = new Offspring("R03", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Workflow.PENDING, 4, 3000, false);
        assertEquals(9000, o.aggregate(), 0.001);
    }

    @Test public void offspringWithCustody() {
        Offspring o = new Offspring("R04", "Nandi", "White Rhino", "Hluhluwe", "B",
                10, 600, Workflow.PENDING, 4, 3000, true);
        assertEquals(11500, o.aggregate(), 0.001);
    }

    @Test public void rareNoSpecialists() {
        Rare r = new Rare("R05", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Workflow.PENDING, "Critically Endangered", 12000, false);
        assertEquals(17600, r.aggregate(), 0.001);
    }

    @Test public void rareWithSpecialists() {
        Rare r = new Rare("R06", "Shadow", "Black Rhino", "Addo", "C",
                7, 800, Workflow.PENDING, "Critically Endangered", 12000, true);
        assertEquals(25600, r.aggregate(), 0.001);
    }

    // ---- priority bands ----

    @Test public void traumaCritical() {
        Trauma t = new Trauma("R07", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Workflow.PENDING, "Gunshot", 15000, true);
        assertEquals("Critical", t.band());
    }

    @Test public void traumaHigh() {
        Trauma t = new Trauma("R08", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Workflow.PENDING, "Fracture", 13000, false);
        assertEquals("High", t.band());
    }

    @Test public void traumaMedium() {
        Trauma t = new Trauma("R09", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Workflow.PENDING, "Wound", 5000, false);
        assertEquals("Medium", t.band());
    }

    @Test public void traumaLow() {
        Trauma t = new Trauma("R10", "Lion", "African Lion", "Kgalagadi", "D",
                3, 500, Workflow.PENDING, "Cut", 1000, false);
        assertEquals("Low", t.band());
    }

    @Test public void offspringCritical() {
        Offspring o = new Offspring("R11", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Workflow.PENDING, 2, 3000, true);
        assertEquals("Critical", o.band());
    }

    @Test public void offspringHigh() {
        Offspring o = new Offspring("R12", "Baby Elephant", "African Elephant", "Addo", "E",
                5, 400, Workflow.PENDING, 2, 3000, false);
        assertEquals("High", o.band());
    }

    @Test public void offspringMedium() {
        Offspring o = new Offspring("R13", "Young Elephant", "African Elephant", "Addo", "E",
                5, 400, Workflow.PENDING, 8, 3000, false);
        assertEquals("Medium", o.band());
    }

    @Test public void offspringLow() {
        Offspring o = new Offspring("R14", "Juvenile", "African Elephant", "Addo", "E",
                5, 400, Workflow.PENDING, 18, 3000, false);
        assertEquals("Low", o.band());
    }

    @Test public void rareCritical() {
        Rare r = new Rare("R15", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Workflow.PENDING, "Critically Endangered", 9000, true);
        assertEquals("Critical", r.band());
    }

    @Test public void rareHigh() {
        Rare r = new Rare("R16", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Workflow.PENDING, "Critically Endangered", 9000, false);
        assertEquals("High", r.band());
    }

    @Test public void rareMedium() {
        Rare r = new Rare("R17", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Workflow.PENDING, "Endangered", 9000, false);
        assertEquals("Medium", r.band());
    }

    @Test public void rareLow() {
        Rare r = new Rare("R18", "Rhino", "Black Rhino", "Kruger", "F",
                6, 600, Workflow.PENDING, "Vulnerable", 9000, false);
        assertEquals("Low", r.band());
    }

    // ---- status transitions ----

    @Test public void launchMarksRunning() {
        Trauma t = new Trauma("R19", "Zebra", "Plains Zebra", "Etosha", "G",
                4, 150, Workflow.PENDING, "Sprain", 1200, false);
        t.launch();
        assertEquals(Workflow.RUNNING, t.phase());
    }

    @Test public void concludeMarksClosed() {
        Offspring o = new Offspring("R20", "Baby Giraffe", "Giraffe", "Etosha", "G",
                4, 150, Workflow.PENDING, 4, 800, false);
        o.conclude();
        assertEquals(Workflow.CLOSED, o.phase());
    }

    // ---- search ----

    @Test public void fetchExisting() {
        Trauma t = new Trauma("R21", "Leopard", "African Leopard", "Sabie", "H",
                2, 250, Workflow.PENDING, "Snare", 3000, false);
        repo.save(t);
        assertNotNull(repo.fetch("R21"));
        assertEquals("Leopard", repo.fetch("R21").creature());
    }

    @Test public void fetchMissing() {
        assertNull(repo.fetch("R999"));
    }

    @Test public void fetchCaseInsensitive() {
        Offspring o = new Offspring("r22", "Baby Lion", "African Lion", "Kgalagadi", "I",
                3, 200, Workflow.PENDING, 2, 900, true);
        repo.save(o);
        assertNotNull(repo.fetch("R22"));
    }

    // ---- duplicate / blank ID handling ----

    @Test public void rejectDuplicate() {
        repo.save(new Trauma("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Workflow.PENDING, "Horn", 2500, false));
        Trauma clash = new Trauma("R23", "Buffalo", "African Buffalo", "Hluhluwe", "J",
                5, 180, Workflow.PENDING, "Horn", 2500, false);
        assertThrows(IllegalArgumentException.class, () -> repo.save(clash));
    }

    @Test public void rejectDuplicateCaseInsensitive() {
        repo.save(new Rare("R24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Workflow.PENDING, "Endangered", 3000, false));
        Rare clash = new Rare("r24", "Pangolin", "Ground Pangolin", "Limpopo", "K",
                4, 350, Workflow.PENDING, "Endangered", 3000, false);
        assertThrows(IllegalArgumentException.class, () -> repo.save(clash));
    }

    @Test public void rejectBlankId() {
        Trauma t = new Trauma("   ", "Bird", "Eagle", "Drakensberg", "L",
                2, 100, Workflow.PENDING, "Wing", 500, false);
        assertThrows(IllegalArgumentException.class, () -> repo.save(t));
    }

    @Test public void rejectNull() {
        assertThrows(IllegalArgumentException.class, () -> repo.save(null));
    }

    // ---- totals ----

    @Test public void totalsAcrossTwoCases() {
        repo.save(new Trauma("R25", "Elephant", "African Elephant", "Kruger", "A",
                5, 100, Workflow.PENDING, "Leg", 2000, false)); // 2500
        repo.save(new Offspring("R26", "Baby Rhino", "White Rhino", "Hluhluwe", "B",
                10, 200, Workflow.PENDING, 6, 1500, true)); // 6000

        assertEquals(2, repo.count());
        assertEquals(8500, repo.cumulative(), 0.001);
    }
}